clear all;

GeodesicCone([-4,-4,4],[4,4,4]);