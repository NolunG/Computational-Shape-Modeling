clear all;
myproj([3 4 -10] , [5 0])