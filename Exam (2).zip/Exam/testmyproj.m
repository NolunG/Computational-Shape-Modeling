clear all;
myproj([0 0 10] , [5 -1])